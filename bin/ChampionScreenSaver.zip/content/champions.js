var champions = [{
    "name": "Aatrox",
    "skins": ["Skin1", "Skin2"]
}, {
    "name": "Ahri"
}, {
    "name": "Akali"
}, {
    "name": "Alistar"
}, {
    "name": "Amumu"
}, {
    "name": "Anivia"
},{
    "name": "Annie"
}, {
    "name": "Ashe"
}, {
    "name": "Brand"
}, {
    "name": "Caitlyn"
}]